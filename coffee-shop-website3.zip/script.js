let defaultMenu = {
  Hot: [
    { name: "Espresso", price: "3.00", img: "https://via.placeholder.com/150" },
    { name: "Cappuccino", price: "4.00", img: "https://via.placeholder.com/150" },
    { name: "Latte", price: "4.50", img: "https://via.placeholder.com/150" },
    { name: "Americano", price: "3.50", img: "https://via.placeholder.com/150" }
  ],
  Cold: [
    { name: "Iced Coffee", price: "4.00", img: "https://via.placeholder.com/150" },
    { name: "Iced Latte", price: "4.50", img: "https://via.placeholder.com/150" },
    { name: "Cold Brew", price: "5.00", img: "https://via.placeholder.com/150" }
  ],
  Milkshake: [
    { name: "Oreo Milkshake", price: "6.00", img: "https://via.placeholder.com/150" },
    { name: "Vanilla Milkshake", price: "5.50", img: "https://via.placeholder.com/150" },
    { name: "Chocolate Milkshake", price: "5.50", img: "https://via.placeholder.com/150" }
  ],
  Boba: [
    { name: "Strawberry Milk Boba", price: "6.50", img: "https://via.placeholder.com/150" },
    { name: "Passion Mango Boba", price: "6.50", img: "https://via.placeholder.com/150" }
  ],
  Refresher: [
    { name: "Strawberry Refresher", price: "5.00", img: "https://via.placeholder.com/150" },
    { name: "Mango Refresher", price: "5.00", img: "https://via.placeholder.com/150" }
  ],
  Frappe: [
    { name: "Mocha Frappe", price: "5.50", img: "https://via.placeholder.com/150" },
    { name: "Caramel Frappe", price: "5.50", img: "https://via.placeholder.com/150" }
  ],
  "Sugar Free": [
    { name: "Sugar-Free Latte", price: "4.50", img: "https://via.placeholder.com/150" },
    { name: "Sugar-Free Cappuccino", price: "4.50", img: "https://via.placeholder.com/150" }
  ],
  Shisha: [
    { name: "Double Apple", price: "8.00", img: "https://via.placeholder.com/150" },
    { name: "Grape Mint", price: "8.00", img: "https://via.placeholder.com/150" }
  ]
};

let menu = JSON.parse(localStorage.getItem("menuData")) || defaultMenu;

function renderMenu() {
  let container = document.getElementById("menuContainer");
  container.innerHTML = "";
  for (let category in menu) {
    let section = document.createElement("div");
    section.innerHTML = `<h3>${category}</h3>`;
    menu[category].forEach((item, index) => {
      section.innerHTML += `
        <div class="menu-item">
          <img src="${item.img}" alt="${item.name}" />
          <h4>${item.name}</h4>
          <p>$${item.price}</p>
        </div>
      `;
    });
    container.appendChild(section);
  }
}

function openAdmin() {
  let panel = document.getElementById("adminPanel");
  panel.classList.remove("hidden");
  renderAdminItems();
}

function closeAdmin() {
  document.getElementById("adminPanel").classList.add("hidden");
}

function renderAdminItems() {
  let adminContainer = document.getElementById("adminItems");
  adminContainer.innerHTML = "";
  for (let category in menu) {
    let categoryDiv = document.createElement("div");
    categoryDiv.innerHTML = `<h3>${category}</h3>`;
    menu[category].forEach((item, index) => {
      categoryDiv.innerHTML += `
        <div>
          <input type="text" value="${item.name}" onchange="menu['${category}'][${index}].name=this.value">
          <input type="number" value="${item.price}" onchange="menu['${category}'][${index}].price=this.value">
          <input type="file" accept="image/*" onchange="updateImage(event,'${category}',${index})">
          <button onclick="removeItem('${category}',${index})">Remove</button>
        </div>
      `;
    });
    adminContainer.appendChild(categoryDiv);
  }
}

function updateImage(event, category, index) {
  let file = event.target.files[0];
  if (file) {
    let reader = new FileReader();
    reader.onload = function(e) {
      menu[category][index].img = e.target.result;
      renderMenu();
      renderAdminItems();
    }
    reader.readAsDataURL(file);
  }
}

function addNewItem() {
  let category = prompt("Enter category name:");
  if (!menu[category]) menu[category] = [];
  menu[category].push({ name: "New Item", price: "0.00", img: "https://via.placeholder.com/150" });
  renderMenu();
  renderAdminItems();
}

function removeItem(category, index) {
  menu[category].splice(index, 1);
  renderMenu();
  renderAdminItems();
}

function saveChanges() {
  localStorage.setItem("menuData", JSON.stringify(menu));
  alert("Changes saved!");
  renderMenu();
}

renderMenu();
