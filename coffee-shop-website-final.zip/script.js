// ===== Defaults =====
const DEFAULT_PIN = "latte112233";
const DEFAULT_SETTINGS = {
  logoSrc: "assets/logo.svg",
  aboutText: "Welcome to Latte Coffee Shop, where every sip is crafted with love. From hot classics to refreshing bobas and unique shisha flavors, we bring you the perfect blend of tradition and modern taste."
};
const DEFAULT_MENU = {
  "Hot": [
    { name: "Espresso", price: 2.5, img: "assets/bg.svg" },
    { name: "Cappuccino", price: 3.0, img: "assets/bg.svg" },
    { name: "Latte", price: 3.5, img: "assets/bg.svg" },
    { name: "Americano", price: 2.8, img: "assets/bg.svg" }
  ],
  "Cold": [
    { name: "Iced Coffee", price: 3.0, img: "assets/bg.svg" },
    { name: "Iced Latte", price: 3.5, img: "assets/bg.svg" },
    { name: "Cold Brew", price: 3.2, img: "assets/bg.svg" }
  ],
  "Milkshake": [
    { name: "Oreo Milkshake", price: 4.5, img: "assets/bg.svg" },
    { name: "Vanilla Milkshake", price: 4.0, img: "assets/bg.svg" },
    { name: "Chocolate Milkshake", price: 4.2, img: "assets/bg.svg" }
  ],
  "Boba": [
    { name: "Strawberry Milk Boba", price: 5.0, img: "assets/bg.svg" },
    { name: "Passion Mango Boba", price: 5.5, img: "assets/bg.svg" }
  ],
  "Refresher": [
    { name: "Strawberry Refresher", price: 3.8, img: "assets/bg.svg" },
    { name: "Mango Refresher", price: 3.8, img: "assets/bg.svg" }
  ],
  "Frappe": [
    { name: "Mocha Frappe", price: 4.5, img: "assets/bg.svg" },
    { name: "Caramel Frappe", price: 4.5, img: "assets/bg.svg" }
  ],
  "Sugar Free": [
    { name: "Sugar-Free Latte", price: 3.5, img: "assets/bg.svg" },
    { name: "Sugar-Free Cappuccino", price: 3.2, img: "assets/bg.svg" }
  ],
  "Shisha": [
    { name: "Double Apple", price: 6.0, img: "assets/bg.svg" },
    { name: "Grape Mint", price: 6.0, img: "assets/bg.svg" }
  ]
};
const CATEGORIES = Object.keys(DEFAULT_MENU);

// ===== State =====
let settings = JSON.parse(localStorage.getItem("siteSettings") || "null") || DEFAULT_SETTINGS;
let menu = JSON.parse(localStorage.getItem("menuData") || "null") || DEFAULT_MENU;
let activeCategory = CATEGORIES[0];

// ===== Elements =====
const yearEl = document.getElementById("year");
const logoImg = document.getElementById("siteLogo");
const aboutTextEl = document.getElementById("aboutText");
const tabsEl = document.getElementById("categoryTabs");
const gridEl = document.getElementById("menuGrid");
const adminModal = document.getElementById("adminModal");
const openAdminBtn = document.getElementById("openAdminBtn");
const closeAdminBtn = document.getElementById("closeAdmin");
const adminStepAuth = document.getElementById("adminStepAuth");
const adminStepPanel = document.getElementById("adminStepPanel");
const pinInput = document.getElementById("pinInput");
const loginBtn = document.getElementById("loginBtn");
const exportBtn = document.getElementById("exportBtn");
const importFile = document.getElementById("importFile");
const saveAllBtn = document.getElementById("saveAllBtn");
const adminList = document.getElementById("adminList");
const logoInput = document.getElementById("logoInput");
const logoPreview = document.getElementById("logoPreview");
const aboutEditor = document.getElementById("aboutEditor");

yearEl.textContent = new Date().getFullYear();
logoImg.src = settings.logoSrc || "assets/logo.svg";
aboutTextEl.textContent = settings.aboutText || DEFAULT_SETTINGS.aboutText;

// ===== Helpers =====
function toMoney(v){ return '$' + Number(v).toFixed(2); }
function readImageFile(file){
  return new Promise((resolve, reject)=>{
    const reader = new FileReader();
    reader.onload = e => resolve(e.target.result);
    reader.onerror = reject;
    reader.readAsDataURL(file);
  });
}

// ===== Render Tabs =====
function renderTabs(){
  tabsEl.innerHTML = "";
  CATEGORIES.forEach(cat=>{
    const b = document.createElement("button");
    b.className = "tab" + (cat===activeCategory ? " active" : "");
    b.textContent = cat;
    b.onclick = () => { activeCategory = cat; renderMenu(); renderTabs(); };
    tabsEl.appendChild(b);
  });
}

// ===== Render Menu Grid =====
function renderMenu(){
  gridEl.innerHTML = "";
  (menu[activeCategory] || []).forEach((item)=>{
    const card = document.createElement("div");
    card.className = "card";
    const img = document.createElement("img");
    img.className = "card-img";
    img.src = item.img || "assets/bg.svg";
    img.alt = item.name;
    const body = document.createElement("div");
    body.className = "card-body";
    const h = document.createElement("p");
    h.className = "card-title";
    h.textContent = item.name;
    const price = document.createElement("p");
    price.className = "card-price";
    price.textContent = toMoney(item.price);
    body.appendChild(h);
    body.appendChild(price);
    card.appendChild(img);
    card.appendChild(body);
    gridEl.appendChild(card);
  });
}

// ===== Admin Auth =====
openAdminBtn.onclick = () => {
  adminModal.classList.remove("hidden");
  adminStepAuth.style.display = "block";
  adminStepPanel.classList.add("hidden");
  pinInput.value = "";
  logoPreview.src = settings.logoSrc || "assets/logo.svg";
  aboutEditor.value = settings.aboutText || DEFAULT_SETTINGS.aboutText;
};
closeAdminBtn.onclick = () => adminModal.classList.add("hidden");
loginBtn.onclick = () => {
  if ((pinInput.value || '').trim() === DEFAULT_PIN){
    adminStepAuth.style.display = "none";
    adminStepPanel.classList.remove("hidden");
    renderAdminList();
  } else {
    alert("Wrong PIN");
  }
};

// ===== Admin: Site Settings Handlers =====
logoInput.addEventListener("change", async (e)=>{
  const file = e.target.files && e.target.files[0];
  if(!file) return;
  const dataUrl = await readImageFile(file);
  settings.logoSrc = dataUrl;
  logoPreview.src = dataUrl;
});
aboutEditor.addEventListener("input", (e)=>{
  settings.aboutText = e.target.value;
});

// ===== Admin: Menu Editor =====
function renderAdminList(){
  adminList.innerHTML = "";
  CATEGORIES.forEach(cat => {
    const block = document.createElement("div");
    block.className = "category-block";
    const title = document.createElement("h4");
    title.className = "category-title";
    title.textContent = cat;
    block.appendChild(title);

    (menu[cat] || []).forEach((item, idx)=>{
      const row = document.createElement("div");
      row.className = "admin-item";
      const img = document.createElement("img");
      img.src = item.img || "assets/bg.svg";
      img.alt = item.name;
      const name = document.createElement("input");
      name.className = "input";
      name.value = item.name;
      name.placeholder = "Name";
      name.oninput = (e)=> item.name = e.target.value;

      const price = document.createElement("input");
      price.className = "input";
      price.type = "number"; price.step = "0.1";
      price.value = item.price;
      price.oninput = (e)=> item.price = Number(e.target.value || 0);

      const fileWrap = document.createElement("label");
      fileWrap.className = "btn btn-outline";
      fileWrap.textContent = "Change Image";
      const file = document.createElement("input");
      file.type = "file"; file.accept = "image/*"; file.hidden = true;
      file.onchange = async (e)=>{
        const f = e.target.files && e.target.files[0];
        if(!f) return;
        const dataUrl = await readImageFile(f);
        item.img = dataUrl;
        renderAdminList();
        renderMenu();
      };
      fileWrap.appendChild(file);

      const controls = document.createElement("div");
      controls.className = "admin-controls";
      const del = document.createElement("button");
      del.className = "btn btn-danger";
      del.textContent = "Remove";
      del.onclick = ()=>{
        menu[cat].splice(idx,1);
        renderAdminList();
        renderMenu();
      };

      row.appendChild(img);
      row.appendChild(name);
      row.appendChild(price);
      row.appendChild(fileWrap);
      row.appendChild(del);
      block.appendChild(row);
    });

    // Add new row
    const addRow = document.createElement("div");
    addRow.className = "add-row";
    const newName = document.createElement("input");
    newName.className = "input"; newName.placeholder = "New item name";
    const newPrice = document.createElement("input");
    newPrice.className = "input"; newPrice.type = "number"; newPrice.step = "0.1"; newPrice.placeholder = "Price";
    const newBtn = document.createElement("button");
    newBtn.className = "btn btn-success"; newBtn.textContent = "Add Item";
    const newImgInput = document.createElement("input");
    newImgInput.type = "file"; newImgInput.accept = "image/*";
    newImgInput.style.display = "none";
    const newImgBtn = document.createElement("button");
    newImgBtn.className = "btn btn-outline"; newImgBtn.textContent = "Upload Image";
    let newImgData = null;
    newImgBtn.onclick = ()=> newImgInput.click();
    newImgInput.onchange = async (e)=>{
      const f = e.target.files && e.target.files[0];
      if(!f) return;
      newImgData = await readImageFile(f);
      alert("Image ready ✔");
    };
    newBtn.onclick = ()=>{
      const nm = (newName.value || "").trim();
      const pr = Number(newPrice.value || 0);
      if(!nm){ alert("Enter item name"); return; }
      menu[cat] = menu[cat] || [];
      menu[cat].push({ name: nm, price: pr, img: newImgData || "assets/bg.svg" });
      newName.value = ""; newPrice.value = ""; newImgData = null;
      renderAdminList();
      renderMenu();
    };

    addRow.appendChild(newName);
    addRow.appendChild(newPrice);
    addRow.appendChild(newImgBtn);
    addRow.appendChild(newImgInput);
    addRow.appendChild(newBtn);
    block.appendChild(addRow);

    adminList.appendChild(block);
  });
}

// ===== Export / Import / Save =====
exportBtn.onclick = () => {
  const data = { settings, menu };
  const blob = new Blob([JSON.stringify(data, null, 2)], {type: "application/json"});
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url; a.download = "latte_config.json";
  document.body.appendChild(a); a.click(); a.remove();
  URL.revokeObjectURL(url);
};
importFile.onchange = async (e) => {
  const file = e.target.files && e.target.files[0];
  if(!file) return;
  const text = await file.text();
  try{
    const data = JSON.parse(text);
    if(data.settings) settings = data.settings;
    if(data.menu) menu = data.menu;
    // Apply
    document.getElementById("siteLogo").src = settings.logoSrc || "assets/logo.svg";
    document.getElementById("aboutText").textContent = settings.aboutText || "";
    logoPreview.src = settings.logoSrc || "assets/logo.svg";
    aboutEditor.value = settings.aboutText || "";
    renderAdminList(); renderTabs(); renderMenu();
    alert("Imported ✔");
  }catch(err){
    alert("Invalid file");
  }
};
saveAllBtn.onclick = ()=>{
  // Persist settings & menu
  localStorage.setItem("siteSettings", JSON.stringify(settings));
  localStorage.setItem("menuData", JSON.stringify(menu));
  // Apply to site
  document.getElementById("siteLogo").src = settings.logoSrc || "assets/logo.svg";
  document.getElementById("aboutText").textContent = settings.aboutText || "";
  alert("Saved ✔");
};

// ===== Init =====
function init(){
  renderTabs();
  renderMenu();
}
init();
